from crm.extensions import db
from crm.models.commission import Commission

VENDOR_PERCENT = 0.70
PLATFORM_PERCENT = 0.30


def create_commission(payment):
    """
    Payment SUCCESS అయిన తర్వాత commission create అవుతుంది
    """

    # Duplicate check
    existing = Commission.query.filter_by(payment_id=payment.id).first()
    if existing:
        return existing

    total = payment.amount
    vendor_amount = round(total * VENDOR_PERCENT, 2)
    platform_amount = round(total * PLATFORM_PERCENT, 2)

    commission = Commission(
        payment_id=payment.id,
        lead_id=payment.lead_id,
        total_amount=total,
        vendor_amount=vendor_amount,
        platform_amount=platform_amount,
    )

    db.session.add(commission)
    db.session.commit()

    return commission