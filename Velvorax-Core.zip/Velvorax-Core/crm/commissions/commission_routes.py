from flask import Blueprint, jsonify
from crm.models.commission import Commission

commission_bp = Blueprint(
    "commission_bp",
    __name__,
    url_prefix="/api/commissions"
)


@commission_bp.route("/", methods=["GET"])
def list_commissions():
    commissions = Commission.query.order_by(Commission.created_at.desc()).all()
    return jsonify([c.to_dict() for c in commissions])