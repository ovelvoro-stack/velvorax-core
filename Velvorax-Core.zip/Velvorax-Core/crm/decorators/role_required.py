from functools import wraps
from flask import request, jsonify
from crm.auth.jwt_handler import verify_token


def role_required(required_role):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            auth_header = request.headers.get("Authorization")

            if not auth_header:
                return jsonify({"error": "Token missing"}), 401

            try:
                token = auth_header.split(" ")[1]
            except IndexError:
                return jsonify({"error": "Invalid token format"}), 401

            payload = verify_token(token)

            if not payload:
                return jsonify({"error": "Invalid or expired token"}), 401

            if payload.get("role") != required_role:
                return jsonify({"error": "Access denied"}), 403

            return f(*args, **kwargs)

        return wrapper
    return decorator