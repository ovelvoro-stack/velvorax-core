from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.payment import Payment

payment_bp = Blueprint("payment_bp", __name__, url_prefix="/api/payments")


@payment_bp.route("/", methods=["GET"])
def get_payments():
    payments = Payment.query.all()
    result = []

    for payment in payments:
        result.append({
            "id": payment.id,
            "amount": payment.amount,
            "status": payment.status
        })

    return jsonify(result), 200


@payment_bp.route("/", methods=["POST"])
def create_payment():
    data = request.get_json()

    new_payment = Payment(
        amount=data.get("amount"),
        status=data.get("status")
    )

    db.session.add(new_payment)
    db.session.commit()

    return jsonify({"message": "Payment created successfully"}), 200