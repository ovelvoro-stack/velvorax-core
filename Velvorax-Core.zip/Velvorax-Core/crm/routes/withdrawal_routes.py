from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from crm.services.withdrawal_service import WithdrawService

withdraw_bp = Blueprint("withdraw_bp", __name__, url_prefix="/api/withdraw")


@withdraw_bp.route("", methods=["POST"])
@jwt_required()
def request_withdraw():
    user = get_jwt_identity()
    data = request.get_json()

    amount = data.get("amount")

    return WithdrawService.request_withdraw(user["id"], amount)


@withdraw_bp.route("/approve/<int:withdraw_id>", methods=["POST"])
@jwt_required()
def approve_withdraw(withdraw_id):
    return WithdrawService.approve_withdraw(withdraw_id)


@withdraw_bp.route("/history", methods=["GET"])
@jwt_required()
def withdraw_history():
    user = get_jwt_identity()
    return WithdrawService.get_history(user["id"])