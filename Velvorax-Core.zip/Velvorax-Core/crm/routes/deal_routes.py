from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required
from crm.extensions import db
from crm.models.deal import Deal
from crm.services.commission_engine import CommissionEngine

deal_bp = Blueprint("deal_bp", __name__, url_prefix="/deals")


@deal_bp.route("/<int:deal_id>/complete", methods=["POST"])
@jwt_required()
def complete_deal(deal_id):

    deal = Deal.query.get_or_404(deal_id)

    if deal.status == "completed":
        return jsonify({"message": "Deal already completed"}), 400

    deal.status = "completed"
    db.session.commit()

    # 🔥 Commission Apply
    CommissionEngine.apply_commission(deal.id)

    return jsonify({"message": "Deal completed & commission applied"}), 200


@deal_bp.route("/", methods=["GET"])
@jwt_required()
def get_deals():
    deals = Deal.query.all()

    result = []
    for d in deals:
        result.append({
            "id": d.id,
            "title": d.title,
            "amount": d.amount,
            "status": d.status
        })

    return jsonify(result), 200