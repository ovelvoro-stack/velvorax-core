from crm.models.deals import Deal
from crm.extensions import db
from sqlalchemy import func

class RevenueService:

    @staticmethod
    def total_revenue():
        total = db.session.query(func.sum(Deal.amount)).scalar()
        return total or 0