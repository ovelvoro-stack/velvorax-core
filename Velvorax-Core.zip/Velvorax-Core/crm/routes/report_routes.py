from flask import Blueprint, jsonify
from crm.services.revenue_service import RevenueService
from crm.core.role_middleware import admin_required

report_bp = Blueprint("report_bp", __name__, url_prefix="/api/reports")


@report_bp.route("/total", methods=["GET"])
@admin_required
def total_revenue():
    return jsonify(RevenueService.total_revenue())


@report_bp.route("/monthly", methods=["GET"])
@admin_required
def monthly_revenue():
    return jsonify(RevenueService.monthly_revenue())