from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.delivery_models import DeliveryOrder
from crm.models.delivery_engine import process_delivery_order

delivery_bp = Blueprint(
    "delivery_bp",
    __name__,
    url_prefix="/api/delivery"
)

# ==============================
# GET ALL DELIVERY ORDERS
# ==============================
@delivery_bp.route("/", methods=["GET"])
def get_delivery_orders():
    orders = DeliveryOrder.query.all()

    return jsonify([
        {
            "id": o.id,
            "customer_name": o.customer_name,
            "address": o.address,
            "amount": o.amount
        }
        for o in orders
    ])


# ==============================
# CREATE DELIVERY
# ==============================
@delivery_bp.route("/create", methods=["POST"])
def create_delivery():
    data = request.get_json()

    order = process_delivery_order(data)

    return jsonify({
        "message": "Delivery created successfully",
        "order_id": order.id
    }), 201