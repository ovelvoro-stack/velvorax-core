from flask import Flask

from crm.auth.auth_routes import auth_bp
from crm.routes.deals import deals_bp   # ✅ THIS IS CORRECT
from crm.payments.payment_routes import payment_bp
from crm.wallets.wallet_routes import wallet_bp
from crm.extensions import db, jwt

app = Flask(__name__)

# CONFIG
app.config["SECRET_KEY"] = "velvorax-secret-key"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///crm.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["JWT_SECRET_KEY"] = "velvorax-jwt-secret"

# INIT EXTENSIONS
db.init_app(app)
jwt.init_app(app)

# REGISTER BLUEPRINTS
app.register_blueprint(auth_bp)
app.register_blueprint(deals_bp)
app.register_blueprint(payment_bp)
app.register_blueprint(wallet_bp)

@app.route("/")
def home():
    return "Velvorax CRM Running"

if __name__ == "__main__":
    app.run(debug=True)