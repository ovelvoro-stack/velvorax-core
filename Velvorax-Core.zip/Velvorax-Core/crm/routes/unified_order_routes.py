from flask import Blueprint, jsonify
from crm.models.unified_order_model import UnifiedOrder

unified_order_bp = Blueprint("unified_order", __name__, url_prefix="/api/orders")

@unified_order_bp.route("/", methods=["GET"])
def get_all_orders():
    orders = UnifiedOrder.query.all()
    return jsonify([o.to_dict() for o in orders])