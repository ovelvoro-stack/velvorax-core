from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.marketplace_models import MarketplaceOrder

marketplace_bp = Blueprint("marketplace_bp", __name__, url_prefix="/api/marketplace")


@marketplace_bp.route("/", methods=["GET"])
def get_orders():
    orders = MarketplaceOrder.query.all()
    return jsonify([{
        "id": o.id,
        "product_name": o.product_name,
        "amount": o.amount
    } for o in orders])


@marketplace_bp.route("/create", methods=["POST"])
def create_order():
    data = request.json

    order = MarketplaceOrder(
        product_name=data.get("product_name"),
        amount=data.get("amount")
    )

    db.session.add(order)
    db.session.commit()

    return jsonify({"message": "Marketplace order created", "id": order.id})