from flask import Blueprint, jsonify, request

# =====================================
# Wallet Blueprint
# =====================================
wallet_bp = Blueprint("wallet_bp", __name__)

# =====================================
# GET ALL WITHDRAWALS
# Works with:
# /api/withdrawals
# /api/withdrawals/
# =====================================
@wallet_bp.route("/withdrawals", methods=["GET"])
@wallet_bp.route("/withdrawals/", methods=["GET"])
def get_withdrawals():
    return jsonify({
        "status": "success",
        "message": "Withdrawals route working",
        "data": []
    }), 200


# =====================================
# CREATE WITHDRAWAL
# Works with:
# /api/withdrawals
# /api/withdrawals/
# =====================================
@wallet_bp.route("/withdrawals", methods=["POST"])
@wallet_bp.route("/withdrawals/", methods=["POST"])
def create_withdrawal():
    data = request.get_json()

    return jsonify({
        "status": "success",
        "message": "Withdrawal created",
        "input": data
    }), 201