from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required
from crm.core.role_required import role_required
from crm.models.user import User

admin_bp = Blueprint("admin_bp", __name__, url_prefix="/api/admin")


@admin_bp.route("/users", methods=["GET"])
@jwt_required()
@role_required("admin")
def get_all_users():
    users = User.query.all()

    return jsonify([
        {
            "id": user.id,
            "username": user.username,
            "role": user.role,
            "balance": user.balance
        }
        for user in users
    ])