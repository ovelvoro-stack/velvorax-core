from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.commission import Commission

commission_bp = Blueprint("commission_bp", __name__, url_prefix="/api/commissions")


@commission_bp.route("/", methods=["GET"])
def get_commissions():
    commissions = Commission.query.all()
    result = []

    for commission in commissions:
        result.append({
            "id": commission.id,
            "amount": commission.amount,
            "type": commission.type
        })

    return jsonify(result), 200


@commission_bp.route("/", methods=["POST"])
def create_commission():
    data = request.get_json()

    new_commission = Commission(
        amount=data.get("amount"),
        type=data.get("type")
    )

    db.session.add(new_commission)
    db.session.commit()

    return jsonify({"message": "Commission created successfully"}), 200