from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required

notification_bp = Blueprint("notification_bp", __name__, url_prefix="/api/notifications")

@notification_bp.route("/", methods=["GET"])
@jwt_required()
def get_notifications():
    return jsonify({"message": "Notifications working"}), 200