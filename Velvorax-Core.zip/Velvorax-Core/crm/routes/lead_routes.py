from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.lead import Lead

lead_bp = Blueprint("lead_bp", __name__, url_prefix="/api/leads")


@lead_bp.route("/", methods=["GET"])
def get_leads():
    leads = Lead.query.all()
    result = []

    for lead in leads:
        result.append({
            "id": lead.id,
            "name": lead.name,
            "email": lead.email,
            "phone": lead.phone
        })

    return jsonify(result), 200


@lead_bp.route("/", methods=["POST"])
def create_lead():
    data = request.get_json()

    new_lead = Lead(
        name=data.get("name"),
        email=data.get("email"),
        phone=data.get("phone")
    )

    db.session.add(new_lead)
    db.session.commit()

    return jsonify({"message": "Lead created successfully"}), 200