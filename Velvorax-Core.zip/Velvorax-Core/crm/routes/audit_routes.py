from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required
from crm.core.role_middleware import role_required
from crm.models.withdrawal import Withdrawal
from crm.models.user import User

audit_bp = Blueprint("audit_bp", __name__, url_prefix="/api/audit")


@audit_bp.route("/summary", methods=["GET"])
@jwt_required()
@role_required("admin")
def audit_summary():

    total_users = User.query.count()
    total_withdrawals = Withdrawal.query.count()

    return jsonify({
        "audit_users": total_users,
        "audit_withdrawals": total_withdrawals
    })