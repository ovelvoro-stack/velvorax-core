from flask import Blueprint, jsonify
from crm.services.revenue_service import RevenueService
from crm.core.role_middleware import admin_required
from crm.models.user import User
from crm.models.withdrawal import Withdrawal
from crm.extensions import db
from sqlalchemy import func


dashboard_bp = Blueprint("dashboard_bp", __name__, url_prefix="/api/dashboard")


@dashboard_bp.route("/summary", methods=["GET"])
@admin_required
def summary():

    total_users = User.query.count()
    total_withdraw = db.session.query(func.sum(Withdrawal.amount)).scalar() or 0
    total_revenue = RevenueService.total_revenue()["total_revenue"]

    return jsonify({
        "total_users": total_users,
        "total_withdraw": float(total_withdraw),
        "total_revenue": total_revenue
    })


@dashboard_bp.route("/monthly", methods=["GET"])
@admin_required
def monthly():

    return jsonify({
        "monthly_revenue": RevenueService.monthly_revenue()
    })