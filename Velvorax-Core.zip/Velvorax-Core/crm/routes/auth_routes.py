from flask import Blueprint, jsonify
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    jwt_required,
    get_jwt_identity
)

auth_bp = Blueprint("auth_bp", __name__, url_prefix="/api/auth")


@auth_bp.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()

    new_access = create_access_token(identity=identity)
    new_refresh = create_refresh_token(identity=identity)

    return jsonify({
        "access_token": new_access,
        "refresh_token": new_refresh
    })