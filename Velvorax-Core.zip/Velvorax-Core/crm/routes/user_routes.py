from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required

user_bp = Blueprint("user_bp", __name__, url_prefix="/api/users")

@user_bp.route("/", methods=["GET"])
@jwt_required()
def get_users():
    return jsonify({"message": "Users route working"}), 200