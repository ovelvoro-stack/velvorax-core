from flask import Blueprint, jsonify
from .wallet_service import get_wallet_by_user

wallet_bp = Blueprint("wallet", __name__, url_prefix="/api")

@wallet_bp.route("/wallet/<int:user_id>", methods=["GET"])
def get_wallet(user_id):
    wallet = get_wallet_by_user(user_id)

    if not wallet:
        return jsonify({"message": "Wallet not found"}), 404

    return jsonify(wallet), 200