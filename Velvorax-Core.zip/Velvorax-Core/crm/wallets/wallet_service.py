from crm.extensions import db
from crm.models.wallet import Wallet
from datetime import datetime


def credit_wallet(user_id, amount):

    wallet = Wallet.query.filter_by(user_id=user_id).first()

    if not wallet:
        wallet = Wallet(
            user_id=user_id,
            balance=0,
            created_at=datetime.utcnow()
        )
        db.session.add(wallet)
        db.session.commit()

    vendor_share = amount * 0.70
    wallet.balance += vendor_share

    db.session.commit()

    return wallet


def get_wallet_by_user(user_id):

    wallet = Wallet.query.filter_by(user_id=user_id).first()

    if not wallet:
        return {"message": "Wallet not found"}, 404

    return {
        "user_id": wallet.user_id,
        "balance": wallet.balance,
        "created_at": wallet.created_at
    }