from crm.extensions import db

class Payment(db.Model):
    __tablename__ = "payments"

    id = db.Column(db.Integer, primary_key=True)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50))

    def to_dict(self):
        return {
            "id": self.id,
            "amount": self.amount,
            "status": self.status
        }