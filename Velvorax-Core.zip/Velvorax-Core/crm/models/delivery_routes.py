from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.delivery_models import DeliveryOrder
from crm.models.delivery_engine import process_delivery_order

delivery_bp = Blueprint(
    "delivery_bp",
    __name__,
    url_prefix="/api/delivery"
)

@delivery_bp.route("/create", methods=["GET", "POST"])
def create_delivery():

    # If GET → show instruction
    if request.method == "GET":
        return jsonify({
            "message": "Use POST method to create delivery order",
            "example_body": {
                "customer_name": "Raju",
                "address": "Hyderabad",
                "amount": 1000
            }
        }), 200

    # If POST → create order
    data = request.get_json()

    if not data:
        return jsonify({"error": "JSON body required"}), 400

    order = DeliveryOrder(
        customer_name=data.get("customer_name"),
        address=data.get("address"),
        amount=data.get("amount")
    )

    db.session.add(order)
    db.session.commit()

    commission = process_delivery_order(order)

    return jsonify({
        "message": "Delivery Order Created Successfully",
        "order_id": order.id,
        "vendor_share": commission[0],
        "platform_share": commission[1]
    }), 201