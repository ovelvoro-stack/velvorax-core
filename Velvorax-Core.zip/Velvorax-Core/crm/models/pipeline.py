from crm.extensions import db
from datetime import datetime

class Pipeline(db.Model):
    __tablename__ = "pipeline"

    id = db.Column(db.Integer, primary_key=True)
    lead_id = db.Column(db.Integer, db.ForeignKey("leads.id"))
    stage = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    lead = db.relationship("Lead", backref="pipeline_entries")

    def to_dict(self):
        return {
            "id": self.id,
            "lead_id": self.lead_id,
            "stage": self.stage,
            "created_at": self.created_at
        }