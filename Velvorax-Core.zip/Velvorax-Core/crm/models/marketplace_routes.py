from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.marketplace_models import MarketplaceOrder

marketplace_bp = Blueprint(
    "marketplace_bp",
    __name__,
    url_prefix="/api/marketplace"
)

@marketplace_bp.route("/create", methods=["GET", "POST"])
def create_marketplace():

    if request.method == "GET":
        return jsonify({
            "message": "Use POST method to create marketplace order",
            "example_body": {
                "product_name": "Laptop",
                "amount": 50000
            }
        }), 200

    data = request.get_json()

    if not data:
        return jsonify({"error": "JSON body required"}), 400

    order = MarketplaceOrder(
        product_name=data.get("product_name"),
        amount=data.get("amount")
    )

    db.session.add(order)
    db.session.commit()

    return jsonify({
        "message": "Marketplace Order Created Successfully",
        "order_id": order.id
    }), 201