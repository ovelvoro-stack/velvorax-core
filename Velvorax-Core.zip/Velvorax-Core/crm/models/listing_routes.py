from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.listing_model import Listing
from crm.engines.unified_order_engine import create_unified_order

listing_bp = Blueprint("listing", __name__, url_prefix="/api/listings")

@listing_bp.route("/create", methods=["POST"])
def create_listing():
    data = request.json

    listing = Listing(
        title=data["title"],
        description=data.get("description"),
        price=data["price"],
        category=data.get("category")
    )

    db.session.add(listing)
    db.session.commit()

    create_unified_order("listing", listing.id, listing.price)

    return jsonify(listing.to_dict()), 201

@listing_bp.route("/", methods=["GET"])
def get_listings():
    listings = Listing.query.all()
    return jsonify([l.to_dict() for l in listings])