from crm.extensions import db
from datetime import datetime


class Listing(db.Model):
    __tablename__ = "listings"

    id = db.Column(db.Integer, primary_key=True)

    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)

    category = db.Column(db.String(100), nullable=True)
    price = db.Column(db.Float, nullable=False)

    vendor_id = db.Column(db.Integer, nullable=False)

    status = db.Column(db.String(50), default="active")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "category": self.category,
            "price": self.price,
            "vendor_id": self.vendor_id,
            "status": self.status,
            "created_at": self.created_at
        }