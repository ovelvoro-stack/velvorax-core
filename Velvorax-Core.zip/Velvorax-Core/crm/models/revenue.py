from crm.extensions import db

class Revenue(db.Model):
    __tablename__ = "revenues"

    id = db.Column(db.Integer, primary_key=True)
    deal_id = db.Column(db.Integer, nullable=False)
    total_amount = db.Column(db.Float, nullable=False)
    commission_paid = db.Column(db.Float, nullable=False)
    platform_share = db.Column(db.Float, nullable=False)