from crm.models.module_commission_rule import ModuleCommissionRule


def calculate_module_commission(module_name, amount):
    """
    Calculate commission based on module rules.
    Default: 70% Vendor / 30% Platform
    """

    rule = ModuleCommissionRule.query.filter_by(
        module_name=module_name
    ).first()

    percent = rule.commission_percent if rule else 30.0

    platform_share = amount * percent / 100
    vendor_share = amount - platform_share

    return vendor_share, platform_share