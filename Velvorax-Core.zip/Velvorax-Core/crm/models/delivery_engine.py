from crm.extensions import db
from crm.models.delivery_models import DeliveryOrder
from crm.models.unified_order_model import UnifiedOrder


def process_delivery_order(data):
    order = DeliveryOrder(
        customer_name=data["customer_name"],
        address=data["address"],
        amount=data["amount"],
    )

    db.session.add(order)
    db.session.flush()

    unified = UnifiedOrder(
        module="delivery",
        reference_id=order.id,
        customer_name=order.customer_name,
        amount=order.amount,
    )

    db.session.add(unified)
    db.session.commit()

    return order