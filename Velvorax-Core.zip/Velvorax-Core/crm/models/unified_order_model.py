from crm.extensions import db
from datetime import datetime


class UnifiedOrder(db.Model):
    __tablename__ = "unified_orders"

    # Prevent duplicate table definition error
    __table_args__ = {"extend_existing": True}

    id = db.Column(db.Integer, primary_key=True)

    module = db.Column(db.String(50), nullable=False)
    reference_id = db.Column(db.Integer, nullable=False)

    customer_name = db.Column(db.String(120), nullable=False)
    amount = db.Column(db.Float, nullable=False)

    status = db.Column(db.String(50), default="pending")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<UnifiedOrder {self.id}>"