from crm.extensions import db

class ModuleCommissionRule(db.Model):
    __tablename__ = "module_commission_rules"

    id = db.Column(db.Integer, primary_key=True)
    module_name = db.Column(db.String(50), unique=True)
    commission_percent = db.Column(db.Float, default=30.0)  # platform %