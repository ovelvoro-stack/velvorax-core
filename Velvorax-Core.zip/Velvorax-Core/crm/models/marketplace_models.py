from crm.extensions import db
from datetime import datetime


class MarketplaceOrder(db.Model):
    __tablename__ = "marketplace_orders"

    id = db.Column(db.Integer, primary_key=True)

    product_name = db.Column(db.String(120), nullable=False)
    customer_name = db.Column(db.String(120), nullable=False)

    amount = db.Column(db.Float, nullable=False)

    status = db.Column(db.String(50), default="pending")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<MarketplaceOrder {self.id}>"