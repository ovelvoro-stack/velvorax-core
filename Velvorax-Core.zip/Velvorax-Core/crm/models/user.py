from crm.extensions import db

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True)
    password = db.Column(db.String(200))
    role = db.Column(db.String(50), default="user")
    balance = db.Column(db.Float, default=0.0)
    active = db.Column(db.Boolean, default=True)