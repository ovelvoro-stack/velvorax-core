from flask import Blueprint, request, jsonify
from crm.extensions import db
from crm.models.service_model import Service
from crm.engines.unified_order_engine import create_unified_order

service_bp = Blueprint("service", __name__, url_prefix="/api/services")

@service_bp.route("/create", methods=["POST"])
def create_service():
    data = request.json

    service = Service(
        name=data["name"],
        description=data.get("description"),
        base_price=data["base_price"],
        provider_name=data.get("provider_name")
    )

    db.session.add(service)
    db.session.commit()

    create_unified_order("service", service.id, service.base_price)

    return jsonify(service.to_dict()), 201

@service_bp.route("/", methods=["GET"])
def get_services():
    services = Service.query.all()
    return jsonify([s.to_dict() for s in services])