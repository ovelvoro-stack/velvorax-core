from flask import Blueprint, request, jsonify
from crm.extensions import db

from crm.modules.delivery.delivery_models import DeliveryOrder
from crm.modules.delivery.delivery_engine import process_delivery_order

delivery_bp = Blueprint(
    "delivery_bp",
    __name__,
    url_prefix="/api/delivery"
)

@delivery_bp.route("/create", methods=["POST"])
def create_delivery():
    data = request.get_json()

    order = DeliveryOrder(
        customer_name=data.get("customer_name"),
        address=data.get("address"),
        amount=data.get("amount")
    )

    db.session.add(order)
    db.session.commit()

    # Commission + Unified Order Integration
    result = process_delivery_order(order)

    return jsonify({
        "message": "Delivery Order Created",
        "commission": result
    }), 201