"""
Velvorax-Core
Audit Log Model

Rules:
- Single shared db instance
- No reserved names
- Production safe
"""

from datetime import datetime
from crm.extensions import db


class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(db.Integer, nullable=True)

    action = db.Column(db.String(255), nullable=False)

    entity_type = db.Column(db.String(100), nullable=True)
    entity_id = db.Column(db.Integer, nullable=True)

    extra_data = db.Column(db.Text, nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<AuditLog {self.action}>"