from crm.modules.unified_order import UnifiedOrder
from crm.modules.module_commission_engine import calculate_module_commission
from crm.extensions import db

def process_marketplace_order(order):
    unified = UnifiedOrder(
        module_name="marketplace",
        reference_id=order.id,
        amount=order.amount,
        status="CREATED"
    )
    db.session.add(unified)
    db.session.commit()

    vendor_share, platform_share = calculate_module_commission("marketplace", order.amount)

    return {
        "vendor_share": vendor_share,
        "platform_share": platform_share
    }