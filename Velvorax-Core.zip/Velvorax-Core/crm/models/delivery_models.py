from crm.extensions import db
from datetime import datetime


class DeliveryOrder(db.Model):
    __tablename__ = "delivery_orders"

    id = db.Column(db.Integer, primary_key=True)

    customer_name = db.Column(db.String(120), nullable=False)
    address = db.Column(db.String(255), nullable=False)

    amount = db.Column(db.Float, nullable=False)

    status = db.Column(db.String(50), default="pending")

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<DeliveryOrder {self.id}>"