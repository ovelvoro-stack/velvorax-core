# crm/utils/logger.py

import logging
from logging.handlers import RotatingFileHandler
import os

def setup_logger(app):
    if not os.path.exists("logs"):
        os.mkdir("logs")

    file_handler = RotatingFileHandler(
        "logs/velvorax.log",
        maxBytes=10240,
        backupCount=5
    )

    formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(name)s - %(message)s"
    )

    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)

    app.logger.addHandler(file_handler)
    app.logger.setLevel(logging.INFO)

    app.logger.info("Velvorax logging initialized.")