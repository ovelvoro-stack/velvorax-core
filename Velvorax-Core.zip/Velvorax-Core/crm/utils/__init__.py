# crm/utils/__init__.py

from .logger import setup_logger
from .error_handler import register_error_handlers

__all__ = ["setup_logger", "register_error_handlers"]