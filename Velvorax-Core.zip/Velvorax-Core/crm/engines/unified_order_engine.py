from crm.extensions import db
from crm.models.unified_order_model import UnifiedOrder

def create_unified_order(source_type, source_id, amount):
    order = UnifiedOrder(
        source_type=source_type,
        source_id=source_id,
        amount=amount
    )
    db.session.add(order)
    db.session.commit()
    return order