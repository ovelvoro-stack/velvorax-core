from flask import Flask
from flask_jwt_extended import JWTManager
from crm.extensions import db
from crm.core.error_handler import register_error_handlers

# Blueprints
from crm.routes.auth_routes import auth_bp
from crm.routes.user_routes import user_bp
from crm.routes.lead_routes import lead_bp
from crm.routes.deal_routes import deal_bp
from crm.routes.withdrawal_routes import withdraw_bp
from crm.routes.audit_routes import audit_bp
from crm.routes.admin_routes import admin_bp
from crm.routes.dashboard_routes import dashboard_bp


jwt = JWTManager()


def create_app():
    app = Flask(__name__)

    # -----------------------------
    # BASIC CONFIG
    # -----------------------------
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///crm.db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["JWT_SECRET_KEY"] = "super-secret-key"

    # -----------------------------
    # INIT EXTENSIONS
    # -----------------------------
    db.init_app(app)
    jwt.init_app(app)

    # -----------------------------
    # REGISTER BLUEPRINTS
    # -----------------------------
    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(lead_bp)
    app.register_blueprint(deal_bp)
    app.register_blueprint(withdraw_bp)
    app.register_blueprint(audit_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(dashboard_bp)

    # -----------------------------
    # ERROR HANDLER
    # -----------------------------
    register_error_handlers(app)

    return app