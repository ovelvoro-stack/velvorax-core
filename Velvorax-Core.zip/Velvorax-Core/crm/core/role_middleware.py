from functools import wraps
from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity
from flask import jsonify
from crm.models.user import User


def role_required(required_role):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            verify_jwt_in_request()
            identity = get_jwt_identity()

            user = User.query.filter_by(username=identity).first()

            if not user:
                return jsonify({"error": "User not found"}), 404

            if user.role != required_role:
                return jsonify({"error": "Unauthorized"}), 403

            return fn(*args, **kwargs)
        return wrapper
    return decorator


def admin_required(fn):
    return role_required("admin")(fn)