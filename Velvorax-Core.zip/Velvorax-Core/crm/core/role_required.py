from functools import wraps
from flask_jwt_extended import get_jwt_identity
from flask import jsonify
from crm.models.user import User


def role_required(required_role):
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            user_identity = get_jwt_identity()

            user = User.query.get(user_identity["id"])

            if not user or user.role != required_role:
                return jsonify({"error": "Access denied"}), 403

            return fn(*args, **kwargs)

        return decorator
    return wrapper