from datetime import datetime
from crm.extensions import db
from crm.models.payment import Payment
from crm.models.lead import Lead
from crm.wallets.wallet_service import credit_wallet   # ✅ CORRECT IMPORT


# =========================================
# CREATE PAYMENT
# =========================================
def create_payment(data):

    lead_id = data.get("lead_id")
    amount = data.get("amount")
    transaction_id = data.get("transaction_id")

    lead = Lead.query.get(lead_id)

    if not lead:
        return {"error": "Lead not found"}, 404

    payment = Payment(
        lead_id=lead_id,
        amount=amount,
        status="SUCCESS",
        transaction_id=transaction_id,
        created_at=datetime.utcnow()
    )

    db.session.add(payment)

    # Update Lead Payment Status
    lead.payment_status = "PAID"

    db.session.commit()

    # =================================
    # AUTO WALLET CREDIT
    # =================================
    try:
        credit_wallet(lead.vendor_id, amount)
    except Exception as e:
        print("Wallet credit failed:", str(e))

    return {
        "message": "Payment created successfully",
        "payment_id": payment.id
    }, 201


# =========================================
# GET ALL PAYMENTS
# =========================================
def get_all_payments():

    payments = Payment.query.order_by(Payment.created_at.desc()).all()

    result = []

    for p in payments:
        result.append({
            "id": p.id,
            "lead_id": p.lead_id,
            "amount": p.amount,
            "status": p.status,
            "transaction_id": p.transaction_id,
            "created_at": p.created_at
        })

    return result