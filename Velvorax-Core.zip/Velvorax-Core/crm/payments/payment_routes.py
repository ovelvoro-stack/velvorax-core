from flask import Blueprint, request, jsonify
from crm.payments.payment_service import create_payment, get_all_payments

payment_bp = Blueprint(
    "payment_bp",
    __name__,
    url_prefix="/api/payments"
)

# ==============================
# GET ALL PAYMENTS
# ==============================
@payment_bp.route("/", methods=["GET"])
def list_payments():
    payments = get_all_payments()
    return jsonify(payments)


# ==============================
# CREATE PAYMENT
# ==============================
@payment_bp.route("/", methods=["POST"])
def create_payment_route():
    data = request.get_json()

    payment = create_payment(
        lead_id=data.get("lead_id"),
        amount=data.get("amount"),
        transaction_id=data.get("transaction_id")
    )

    if not payment:
        return jsonify({"message": "Lead not found"}), 404

    return jsonify({
        "message": "Payment created successfully",
        "payment_id": payment.id
    }), 201