from crm.automation.automation_logs import log_automation
from crm.automation.followup_scheduler import schedule_followup

def dispatch_event(event_type, lead):
    if event_type == "lead_created":
        log_automation(lead.id, "Lead Created")
        schedule_followup(lead.id)