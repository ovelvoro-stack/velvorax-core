from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from crm.extensions import db
from crm.models.lead import Lead
from crm.automation.automation_logs import log_automation

scheduler = BackgroundScheduler()

def start_scheduler():
    scheduler.start()

def schedule_followup(lead_id):
    scheduler.add_job(
        func=send_followup,
        trigger="date",
        run_date=datetime.utcnow(),
        args=[lead_id]
    )

def send_followup(lead_id):
    lead = Lead.query.get(lead_id)
    if lead and lead.followup_status == "pending":
        lead.followup_status = "sent"
        db.session.commit()
        log_automation(lead_id, "Followup Sent")