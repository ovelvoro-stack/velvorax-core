from crm.models.automation_log import AutomationLog
from crm.extensions import db

def log_automation(lead_id, action):
    log = AutomationLog(
        lead_id=lead_id,
        action=action
    )
    db.session.add(log)
    db.session.commit()