# crm/validators/lead_validator.py

def validate_lead_data(data):
    required_fields = ["name", "phone"]

    for field in required_fields:
        if field not in data or not data[field]:
            return False, f"{field} is required"

    if len(data["phone"]) < 8:
        return False, "Invalid phone number"

    return True, None