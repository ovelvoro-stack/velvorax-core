# crm/validators/payment_validator.py

def validate_payment_data(data):
    required_fields = ["lead_id", "amount"]

    for field in required_fields:
        if field not in data:
            return False, f"{field} is required"

    try:
        amount = float(data["amount"])
        if amount <= 0:
            return False, "Amount must be greater than 0"
    except:
        return False, "Invalid amount format"

    return True, None