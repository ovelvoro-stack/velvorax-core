from flask import Blueprint, request, jsonify, g
from crm.auth.auth_service import register_user, login_user
from crm.auth.jwt_handler import jwt_required

auth_bp = Blueprint("auth_bp", __name__)


# ===============================
# PROTECTED ROUTE (JWT REQUIRED)
# ===============================
@auth_bp.route("/protected", methods=["GET"])
@jwt_required
def protected_route():
    return jsonify({
        "message": "Protected route accessed successfully",
        "user_id": g.current_user.id,
        "role": g.current_user.role
    }), 200


# ===============================
# REGISTER
# ===============================
@auth_bp.route("/register", methods=["GET", "POST"])
def register():

    # Browser GET testing support
    if request.method == "GET":
        return jsonify({
            "message": "Use POST method with JSON body to register user",
            "required_json": {
                "username": "string",
                "email": "string",
                "password": "string",
                "role": "admin or user"
            }
        }), 200

    # POST logic
    data = request.get_json()

    if not data:
        return jsonify({"error": "JSON body required"}), 400

    username = data.get("username")
    email = data.get("email")
    password = data.get("password")
    role = data.get("role", "user")

    if not username or not email or not password:
        return jsonify({"error": "username, email and password required"}), 400

    result, status_code = register_user(username, email, password, role)
    return jsonify(result), status_code


# ===============================
# LOGIN
# ===============================
@auth_bp.route("/login", methods=["GET", "POST"])
def login():

    # Browser GET testing support
    if request.method == "GET":
        return jsonify({
            "message": "Use POST method with JSON body to login",
            "required_json": {
                "email": "string",
                "password": "string"
            }
        }), 200

    # POST logic
    data = request.get_json()

    if not data:
        return jsonify({"error": "JSON body required"}), 400

    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({"error": "email and password required"}), 400

    result, status_code = login_user(email, password)
    return jsonify(result), status_code