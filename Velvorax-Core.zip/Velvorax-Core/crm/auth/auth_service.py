from crm.models.user import User
from crm.extensions import db
from crm.auth.jwt_handler import generate_token


def register_user(data):
    username = data.get("username")
    email = data.get("email")
    password = data.get("password")
    role = data.get("role", "user")

    if User.query.filter_by(email=email).first():
        return None, "Email already exists"

    user = User(
        username=username,
        email=email,
        role=role
    )
    user.set_password(password)

    db.session.add(user)
    db.session.commit()

    return user, None


def login_user(data):
    email = data.get("email")
    password = data.get("password")

    user = User.query.filter_by(email=email).first()

    if not user:
        return None, "Invalid credentials"

    if not user.check_password(password):
        return None, "Invalid credentials"

    token = generate_token(user)

    return token, None