from flask import Blueprint, request, jsonify

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    return jsonify({
        "message": "Login working",
        "data": data
    })

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    return jsonify({
        "message": "Register working",
        "data": data
    })