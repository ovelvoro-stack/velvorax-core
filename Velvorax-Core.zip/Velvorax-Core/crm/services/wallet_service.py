from datetime import datetime
from crm.extensions import db
from crm.models.wallet import Wallet


class WalletService:

    @staticmethod
    def credit_wallet(user_id, amount):
        """
        Auto credit wallet on commission approval.
        """
        try:
            wallet = Wallet.query.filter_by(user_id=user_id).first()

            if not wallet:
                wallet = Wallet(
                    user_id=user_id,
                    balance=0,
                    created_at=datetime.utcnow()
                )
                db.session.add(wallet)
                db.session.flush()

            wallet.balance += float(amount)
            wallet.updated_at = datetime.utcnow()

            db.session.commit()

            return wallet

        except Exception:
            db.session.rollback()
            raise