from crm.extensions import db
from crm.models.deal import Deal
from crm.models.user import User
from crm.services.audit_service import AuditService

class CommissionEngine:

    COMMISSION_PERCENT = 10

    @staticmethod
    def apply_commission(deal_id):
        deal = Deal.query.get(deal_id)
        if not deal:
            return

        user = User.query.get(deal.user_id)
        if not user:
            return

        commission = (deal.amount * CommissionEngine.COMMISSION_PERCENT) / 100

        user.balance += commission
        db.session.commit()

        AuditService.log(
            username=user.username,
            action=f"Commission added: {commission}"
        )