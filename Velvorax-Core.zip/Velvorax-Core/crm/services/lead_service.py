from datetime import datetime
from crm.extensions import db
from crm.models.lead import Lead
from crm.models.user import User
from crm.services.commission_service import CommissionService


class LeadService:

    @staticmethod
    def create_lead(data, created_by):
        """
        Create new lead with basic scoring logic.
        """
        try:
            score = LeadService._calculate_score(data)

            lead = Lead(
                name=data.get("name"),
                email=data.get("email"),
                phone=data.get("phone"),
                source=data.get("source"),
                status="NEW",
                score=score,
                created_by=created_by,
                created_at=datetime.utcnow()
            )

            db.session.add(lead)
            db.session.commit()

            return lead

        except Exception:
            db.session.rollback()
            raise

    @staticmethod
    def update_status(lead_id, status):
        """
        Update lead status and trigger commission if converted.
        """
        try:
            lead = Lead.query.get(lead_id)
            if not lead:
                return None

            lead.status = status
            db.session.commit()

            # Trigger revenue flow if converted
            if status == "CONVERTED":
                CommissionService.generate_from_lead(lead)

            return lead

        except Exception:
            db.session.rollback()
            raise

    @staticmethod
    def _calculate_score(data):
        """
        Simple scoring engine.
        """
        score = 0

        if data.get("email"):
            score += 20
        if data.get("phone"):
            score += 20
        if data.get("source") == "website":
            score += 30

        return score