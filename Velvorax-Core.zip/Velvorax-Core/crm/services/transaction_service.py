from crm.extensions import db
from crm.models.user import User

def safe_deduct_balance(user_id, amount):
    user = User.query.get(user_id)

    if not user or user.balance < amount:
        return False, "Insufficient balance"

    user.balance -= amount
    db.session.commit()
    return True, "Balance deducted"