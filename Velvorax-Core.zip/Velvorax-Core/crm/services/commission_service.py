"""
Velvorax-Core
Commission Service – Enterprise Locked Version

Rules:
- No duplicate DB
- Atomic transaction
- Auto wallet credit
- Audit log attach
- Production safe
"""

from crm.extensions import db
from crm.models.commission import Commission
from crm.models.wallet import Wallet
from crm.models.audit_log import AuditLog


class CommissionService:

    @staticmethod
    def calculate_and_credit(deal_id, user_id, amount):
        try:
            # =============================
            # Commission Calculation Logic
            # =============================
            commission_rate = 0.10  # 10% example
            commission_amount = amount * commission_rate
            platform_share = amount - commission_amount

            # =============================
            # Create Commission Record
            # =============================
            commission = Commission(
                deal_id=deal_id,
                user_id=user_id,
                amount=commission_amount,
                platform_share=platform_share,
                status="credited"
            )

            db.session.add(commission)

            # =============================
            # Wallet Credit
            # =============================
            wallet = Wallet.query.filter_by(user_id=user_id).first()

            if not wallet:
                wallet = Wallet(user_id=user_id, balance=0)
                db.session.add(wallet)

            wallet.balance += commission_amount

            # =============================
            # Audit Log
            # =============================
            audit = AuditLog(
                action="COMMISSION_CREDIT",
                description=f"Commission credited for Deal {deal_id}",
                user_id=user_id
            )

            db.session.add(audit)

            # =============================
            # Commit Transaction
            # =============================
            db.session.commit()

            return {
                "status": "success",
                "commission": commission_amount
            }

        except Exception as e:
            db.session.rollback()
            return {
                "status": "error",
                "message": str(e)
            }