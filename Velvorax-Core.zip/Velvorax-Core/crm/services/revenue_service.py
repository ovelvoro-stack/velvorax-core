from crm.models.deal import Deal
from crm.extensions import db
from sqlalchemy import func

class RevenueService:

    @staticmethod
    def total_revenue():
        total = db.session.query(func.sum(Deal.amount)).scalar() or 0
        return {"total_revenue": float(total)}

    @staticmethod
    def monthly_revenue():
        data = db.session.query(
            func.strftime("%Y-%m", Deal.created_at),
            func.sum(Deal.amount)
        ).group_by(
            func.strftime("%Y-%m", Deal.created_at)
        ).all()

        result = []
        for month, total in data:
            result.append({
                "month": month,
                "revenue": float(total)
            })

        return result