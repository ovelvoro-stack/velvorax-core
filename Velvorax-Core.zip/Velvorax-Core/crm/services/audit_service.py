from crm.extensions import db
from crm.models.audit_log import AuditLog


class AuditService:

    @staticmethod
    def log(user, action):
        entry = AuditLog(user=user, action=action)
        db.session.add(entry)
        db.session.commit()