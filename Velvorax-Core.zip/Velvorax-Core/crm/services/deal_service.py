"""
Velvorax-Core
Deal Service – Enterprise Locked Version
"""

from crm.extensions import db
from crm.models.deal import Deal
from crm.services.commission_service import CommissionService


class DealService:

    @staticmethod
    def close_deal(deal_id):
        deal = Deal.query.get(deal_id)

        if not deal:
            return {"status": "error", "message": "Deal not found"}

        if deal.stage != "WON":
            deal.stage = "WON"
            db.session.commit()

        # Trigger Commission Auto Flow
        result = CommissionService.calculate_and_credit(
            deal_id=deal.id,
            user_id=deal.user_id,
            amount=deal.amount
        )

        return result