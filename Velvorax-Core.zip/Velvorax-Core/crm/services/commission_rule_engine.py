from crm.extensions import db
from crm.models.commission import Commission
from crm.models.wallet import Wallet


def calculate_commission(deal_amount, rule_type="standard"):
    if rule_type == "standard":
        return deal_amount * 0.10

    if rule_type == "premium":
        return deal_amount * 0.20

    return 0


def apply_commission(user_id, deal_id, deal_amount, rule_type="standard"):
    commission_amount = calculate_commission(deal_amount, rule_type)

    commission = Commission(
        user_id=user_id,
        deal_id=deal_id,
        amount=commission_amount
    )

    wallet = Wallet.query.filter_by(user_id=user_id).first()

    if not wallet:
        wallet = Wallet(user_id=user_id, balance=0)
        db.session.add(wallet)

    wallet.balance += commission_amount

    db.session.add(commission)
    db.session.commit()

    return commission