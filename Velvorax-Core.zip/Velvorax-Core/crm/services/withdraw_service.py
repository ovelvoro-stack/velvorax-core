from crm.extensions import db
from crm.models.user import User
from sqlalchemy.orm import with_for_update

class WithdrawService:

    @staticmethod
    def safe_withdraw(user_id, amount):

        user = db.session.query(User)\
            .filter_by(id=user_id)\
            .with_for_update()\
            .first()

        if user.balance < amount:
            return {"error": "Insufficient balance"}

        user.balance -= amount
        db.session.commit()

        return {"message": "Withdraw successful"}