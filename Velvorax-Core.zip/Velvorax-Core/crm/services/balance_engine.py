from crm.extensions import db
from crm.models.user import User

class BalanceEngine:

    @staticmethod
    def deduct_balance(user_id, amount):

        user = User.query.get(user_id)

        if not user:
            return {"error": "User not found"}, 404

        if user.balance < amount:
            return {"error": "Insufficient balance"}, 400

        try:
            user.balance -= amount
            db.session.commit()
            return {"message": "Balance deducted successfully"}

        except Exception as e:
            db.session.rollback()
            return {"error": "Transaction failed"}, 500