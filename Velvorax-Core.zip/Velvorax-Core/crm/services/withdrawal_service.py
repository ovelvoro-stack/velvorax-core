from crm.extensions import db
from crm.models.withdrawal import Withdrawal
from crm.models.wallet import Wallet
from crm.models.audit_log import AuditLog


class WithdrawService:

    @staticmethod
    def request_withdraw(user_id, amount):

        if amount <= 0:
            return {"status": "error", "message": "Invalid amount"}

        try:
            with db.session.begin():

                wallet = Wallet.query.filter_by(user_id=user_id).with_for_update().first()

                if not wallet:
                    return {"status": "error", "message": "Wallet not found"}

                if wallet.balance < amount:
                    return {"status": "error", "message": "Insufficient balance"}

                withdrawal = Withdrawal(
                    user_id=user_id,
                    amount=amount,
                    status="pending"
                )

                db.session.add(withdrawal)

                audit = AuditLog(
                    action="WITHDRAW_REQUEST",
                    description=f"Withdraw request for {amount}",
                    user_id=user_id
                )

                db.session.add(audit)

            return {"status": "success", "message": "Withdraw request created"}

        except Exception as e:
            db.session.rollback()
            return {"status": "error", "message": str(e)}

    @staticmethod
    def approve_withdraw(withdraw_id):

        try:
            with db.session.begin():

                withdrawal = Withdrawal.query.filter_by(id=withdraw_id).with_for_update().first()

                if not withdrawal:
                    return {"status": "error", "message": "Withdraw not found"}

                if withdrawal.status != "pending":
                    return {"status": "error", "message": "Already processed"}

                wallet = Wallet.query.filter_by(user_id=withdrawal.user_id).with_for_update().first()

                if wallet.balance < withdrawal.amount:
                    return {"status": "error", "message": "Insufficient balance"}

                wallet.balance -= withdrawal.amount
                withdrawal.status = "approved"

                audit = AuditLog(
                    action="WITHDRAW_APPROVED",
                    description=f"Withdraw {withdraw_id} approved",
                    user_id=withdrawal.user_id
                )

                db.session.add(audit)

            return {"status": "success", "message": "Withdraw approved"}

        except Exception as e:
            db.session.rollback()
            return {"status": "error", "message": str(e)}