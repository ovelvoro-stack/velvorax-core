from crm.extensions import db
from crm.models.user import User
from flask import jsonify

class WalletEngine:

    @staticmethod
    def credit(user_id, amount):
        user = User.query.get(user_id)

        if not user:
            return jsonify({"error": "User not found"}), 404

        if amount <= 0:
            return jsonify({"error": "Invalid credit amount"}), 400

        user.balance += amount
        db.session.commit()

        return jsonify({"message": "Balance credited", "balance": user.balance})


    @staticmethod
    def debit(user_id, amount):
        user = User.query.get(user_id)

        if not user:
            return jsonify({"error": "User not found"}), 404

        if amount <= 0:
            return jsonify({"error": "Invalid debit amount"}), 400

        if user.balance < amount:
            return jsonify({"error": "Insufficient balance"}), 400

        user.balance -= amount
        db.session.commit()

        return jsonify({"message": "Balance deducted", "balance": user.balance})